

import ssreader


print("running main")


result = ssreader.read_csv("data.csv", types=[str, int, str, int, float])



print(result)




